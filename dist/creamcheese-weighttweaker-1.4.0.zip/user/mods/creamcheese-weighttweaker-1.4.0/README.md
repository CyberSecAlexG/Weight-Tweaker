Visit the config folder and edit the values in the config.json file.
Please change the modCompatibility field to true if you are using mods that change your weight limits.